import java.util.*;
import java.lang.*;
class Assignment24
{
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter size of Array : ");
		int size = sc.nextInt();
		int[] arr = new int[size];
		System.out.print("Enter elements of Array : ");
		int sum = 0;
		for(int i = 0; i<size; i++){
			arr[i] = sc.nextInt();
			sum += arr[i];
		}
		System.out.print("The sum of Array elements is "+sum+" and their average is "+(float)((float)sum/size));
	}
}
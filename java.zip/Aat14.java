import java.util.*;
import java.lang.*;

class Aat14
{
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a String : ");
		String s = sc.nextLine();
		StringBuffer str= new StringBuffer(s);
		for(int i = 0; i < str.length(); i++){
			if(str.charAt(i) == '*'){
				if(i != 0){
					str.delete(i-1,i);
					i--;
				}
				if(str.charAt(i+1) != '*'){
					str.delete(i,i+1);
					i--;
				}
				if(i != str.length()-1 && str.charAt(i+1) != '*'){
					str.delete(i+1,i+2);
					i--;
				}
			}
		}
		System.out.println(str);
	}
}
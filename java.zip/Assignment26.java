import java.util.*;
import java.lang.*;
class Assignment26
{
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter size of Array : ");
		int size = sc.nextInt();
		int[] arr = new int[size];
		System.out.print("Enter elements of Array : ");
		int max = 0, min = 0;
		for(int i = 0; i<size; i++){
			arr[i] = sc.nextInt();
		}
		int search = -1;
		System.out.print("Enter search element : ");
		search = sc.nextInt();
		int index = -1;
		boolean isPresent = false;
		for(int i = 0; i<size; i++){
			if(arr[i] == search){
				isPresent = true;
				index = i;
				break;
			}
		}
		if(isPresent)
			System.out.print(index);
		else
			System.out.print(-1);
	}
}
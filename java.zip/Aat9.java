import java.util.*;
import java.lang.*;

class Aat9
{
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a String : ");
		String str = sc.nextLine();
		if(str.length() > 1)
			for(int i = 0; i < str.length(); i++)
				System.out.print(str.charAt(0)+""+str.charAt(1));
		else
			System.out.print(str);
	}
}
import java.util.*;
import java.lang.*;
class Assignment13
{
	public static void main(String args[]){
		for(int i = 1; i<=9; i++)
			System.out.print(i+"\t ");
		System.out.print("10");
	}
}
import java.util.*;
import java.lang.*;
class Assignment22
{
	public static void main(String args[]){
		for(int i = 1; i<=5; i++)
			System.out.print(i*60+"\t");
	}
}
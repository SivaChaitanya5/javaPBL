package com.automobile.towwheeler;
import com.automobile.*;
class Hero extends  com.automobile.vehicle{
	public int getSpeed() {
		return speed;
	}
	public void radio() {
		System.out.println("Radio Control");
	}
}

class Honda extends com.automobile.vehicle{
	public int getSpeed() {
		return speed;
	}
	public void cdplayer() {
		System.out.println("CD player Control");
	}
}
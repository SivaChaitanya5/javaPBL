import java.util.*;
import java.lang.*;
class Assignment31
{
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter size of Array : ");
		int size = sc.nextInt();
		int[] arr = new int[size];
		System.out.print("Enter elements of Array : ");
		for(int i = 0; i<size; i++){
			arr[i] = sc.nextInt();
		}
		int count = 0;
		int repeat = 0;
		int index = -1;
		for(int i = size-1; i>=0; i--){
			for(int j = 0; j<i; j++){
				if(arr[j] == arr[i]){
					count++;
				}
			}
			if(count > repeat){
				repeat = count;
				index = i;
			}
		}
		if(index != -1)
			System.out.print("Highest Repeted element is "+arr[index]);
		else
			System.out.print("No repeated Elemets");
	}
}
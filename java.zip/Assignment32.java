import java.util.*;
import java.lang.*;
class Assignment32
{
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter size of Array : ");
		int size = sc.nextInt();
		int[] arr = new int[size];
		System.out.print("Enter elements of Array : ");
		for(int i = 0; i<size; i++){
			arr[i] = sc.nextInt();
		}
		int sum = 0;
		for(int i = 0; i<size; i++){
			if(arr[i] == 6){
				for(int j = i+1; j<size; j++)
					if(arr[j] == 7)
						i = j+1;
			}
			if(i < size)
				sum += arr[i];
		}
		System.out.print("Sum = "+sum);
	}
}
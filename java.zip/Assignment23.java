import java.util.*;
import java.lang.*;
class Assignment23
{
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter 'a' value : ");
		int a = sc.nextInt();
		System.out.print("Enter 'b' value : ");
		int b = sc.nextInt();
		int ans = 0;
		int ch = 0;
		int op = 'y';
		while(op == 'y'){
			System.out.println("Choose an Option:\n\t(1) Add\t\t(2) Subtract");
			ch = sc.nextInt();
			switch(ch){
				case 1: System.out.println("Addition of two numbers is "+(a+b));
					break;
				case 2: System.out.println("Subtraction of two numbers is "+(a-b));
					break;
				default: System.out.println("Invalid Option");
					break;
			}
			System.out.println("\nDo you want to continue ? (y/n)  : ");
			op = sc.next().charAt(0);
		}
		sc.close();
	}
}
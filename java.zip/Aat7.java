import java.util.*;
import java.lang.*;

class Aat7
{
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a String : ");
		String str = sc.nextLine();
		String rev = new StringBuffer(str).reverse().toString();
		if(str.equals(rev))
			System.out.println("Given String is Palindrome");
		else
			System.out.println("Given String is NOT a Palindrome");
	}
}
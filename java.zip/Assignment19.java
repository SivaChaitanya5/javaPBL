import java.util.*;
import java.lang.*;
class Assignment19
{
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter Number: ");
		int a = sc.nextInt();
		int temp = a;
		sc.close();
		int sum = 0;
		while(a >= 0){
			for(int i = 1; i< temp-a+1; i++)
				System.out.print("* ");
			System.out.println();
			a--;
		}
	}
}
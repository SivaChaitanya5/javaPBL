import java.util.*;
import java.lang.*;
class Assignment7
{
	public static void main(String args[]){
		Scanner sc1 = new Scanner(System.in);
		System.out.print("Enter Characters: ");
		String a = sc1.nextLine();
		sc1.close();
		if(a.charAt(0) < a.charAt(2))
			System.out.println(a.charAt(0)+","+a.charAt(2));
		else
			System.out.println(a.charAt(2)+","+a.charAt(0));
	}
}
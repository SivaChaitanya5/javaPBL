import java.util.*;
import java.lang.*;
class Box{
	double width, height, depth;
	Box(double w, double h, double d){
		this.width = w; this.height = h; this.depth = d;
	}
	public double volume(){
		return (double)(width*height*depth);
	}
}


class Aat1
{
	public static void main(String args[]){
		Box b = new Box(12.35d, 99.9999d, 4d);
		System.out.println("The Volume of Cube is "+b.volume());
	}
}
import java.util.*;
import java.lang.*;
class Assignment5
{
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.println("Give a number: ");
		int a = sc.nextInt();
		if(a%2 == 0)
			System.out.println("Given number "+a+" is Even");
		else
			System.out.println("Given number "+a+" is Odd");
	}
}
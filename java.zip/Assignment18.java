import java.util.*;
import java.lang.*;
class Assignment18
{
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter Number: ");
		int a = sc.nextInt();
		int temp = a;
		sc.close();
		int sum = 0;
		while(a > 0){
			sum += a%10;
			a /= 10; 
		}
		System.out.println("Sum of digits of "+temp+" = "+sum);
	}
}
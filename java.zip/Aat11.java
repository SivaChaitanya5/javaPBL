import java.util.*;
import java.lang.*;

class Aat11
{
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a String : ");
		String str = sc.nextLine();
		if(str.length() > 2)
			for(int i = 1; i < str.length()-1; i++)
				System.out.print(str.charAt(i));
		else
			System.out.println("String should be greater than 2");
	}
}
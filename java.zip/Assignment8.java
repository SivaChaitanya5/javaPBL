import java.util.*;
import java.lang.*;
class Assignment8
{
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter Characters: ");
		char a = sc.next().charAt(0);
		sc.close();
		if((a >= 'a' && a <= 'z') || (a >= 'A' && a <= 'Z'))
			System.out.println("Alphabet");
		else if(a >= '0' && a <= '9')
			System.out.println("Digit");
		else
			System.out.println("Special Character");
	}
}
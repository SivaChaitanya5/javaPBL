import java.util.*;
import java.lang.*;
import com.automobile.*;

class Aat18
{
	public static void main(String args[]){
		
	}
}
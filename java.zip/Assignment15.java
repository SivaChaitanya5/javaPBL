import java.util.*;
import java.lang.*;
class Assignment15
{
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter Number: ");
		int a = sc.nextInt();
		sc.close();
		int count = 0;
		for(int i = 2; i <= a/2; i++)
			if(a%i == 0)
				count++;
		if(a == 1)
			System.out.println("Given number is Neither Prime nor Composite");
		else if(count == 0)
			System.out.println("Given number is Prime");
		else
			System.out.println("Given number is NOT Prime");
	}
}
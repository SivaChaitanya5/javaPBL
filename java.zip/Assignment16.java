import java.util.*;
import java.lang.*;
class Assignment16
{
	public static void main(String args[]){
		int count = 0;
		for(int j = 10; j<=99; j++){
		for(int i = 2; i <= j/2; i++){
			if(j%i == 0)
				count++;
		}
			if(count == 0)
				System.out.println(j+"\t");
			count = 0;
		}
	}
}
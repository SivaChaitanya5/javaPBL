import java.util.*;
import java.lang.*;
class Assignment30
{
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter size of Array : ");
		int size = sc.nextInt();
		int[] arr = new int[size];
		System.out.print("Enter elements of Array : ");
		for(int i = 0; i<size; i++){
			arr[i] = sc.nextInt();
		}	
		for(int i = size-1; i>=0; i--){
			for(int j = 0; j<i; j++){
				if(arr[j] == arr[i]){
					for(int k = i; k<size-1; k++)
						arr[k] = arr[k+1];
					size--;
					break;
				}
			}
		}
		System.out.print("Modified Array : ");
		for(int i = 0; i<size; i++){
			System.out.print(arr[i] + "  ");
		}
	}
}
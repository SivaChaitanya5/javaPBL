import java.util.*;
import java.lang.*;
class Assignment25
{
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter size of Array : ");
		int size = sc.nextInt();
		int[] arr = new int[size];
		System.out.print("Enter elements of Array : ");
		int max = 0, min = 0;
		for(int i = 0; i<size; i++){
			arr[i] = sc.nextInt();
		}
		max = arr[0];
		min = arr[0];
		for(int i = 1; i<size; i++){
			if(arr[i] > max)
				max = arr[i];
			if(arr[i] < min)
				min = arr[i];
		}
		System.out.print("The Maximum of Array elements is "+max+" and the Minumum is "+min);
	}
}
import java.util.*;
import java.lang.*;
class Patient{
	double weight, height;
	String name;
	Patient(String n,double w, double h){
		this.name = n; this.weight = w; this.height = h;
	}
	public double BMI(){
		return (double)(( weight/( height * height) ) * 703);
	}
}


class Aat2
{
	public static void main(String args[]){
		Patient p = new Patient("Rampo", 55.7, 6.2);
		System.out.println("The BMI of patient is "+p.BMI());
	}
}
import java.util.*;
class Assignment3
{
	public static void main(String args[]){
		int sum = 0;
		sum = Integer.parseInt(args[0]) + Integer.parseInt(args[1]);
		System.out.println("The Sum of "+args[0]+" and "+args[1]+" is "+ sum);
	}
}
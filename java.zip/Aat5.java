import java.util.*;
import java.lang.*;
class Fruit{
	public String name,taste,size;
	public void eat(){		
	}
}

class Apple extends Fruit{
	String name = new String("Apple");
	String taste = new String("Sweet");
	String size = new String("Small");
	public void eat(){
		System.out.println("This is "+name+"\nIt's taste is "+taste);
	}
}

class Orange extends Fruit{
	String name = new String("Orange");
	String taste = new String("Sour");
	String size = new String("Medium");
	public void eat(){
		System.out.println("This is "+name+"\nIt's taste is "+taste);
	}
}

class Aat5
{
	public static void main(String args[]){
		Fruit a = new Apple();
		Fruit o = new Orange();
		a.eat();
		o.eat();
	}
}
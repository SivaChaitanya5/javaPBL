import java.util.*;
import java.lang.*;
class Assignment33
{
	public static void main(String args[]){
		if(args.length != 4)
			System.out.println("Please enter 4 integer numbers");
		else{
			System.out.println("The given array is : ");
			System.out.println(args[0]+"  "+args[1]+"\n"+args[2]+"  "+args[3]);
			System.out.println("The reverse of the array is : ");
			System.out.println(args[3]+"  "+args[2]+"\n"+args[1]+"  "+args[0]);
		}
	}
}
import java.util.*;
import java.lang.*;
class Person{
	private String name = null;
	public void setName(String n){
		this.name = n;
	}
	public String getName(){
		return this.name;
	}
}

class Student extends Person{
	int rollNo = 0;
	public void setRollNo(int r){
		this.rollNo = r;
	}
	public int getRollNo(){
		return this.rollNo;
	}
}

class Teacher extends Person{
	double salary = 0d;
	String subject = null;
	public void setSalary(double sal){
		this.salary = sal;
	}
	public void setSubject(String sub){
		this.subject = sub;
	}
	public double getSalary(){
		return this.salary;
	}
	public String getSubject(){
		return this.subject;
	}
}

class CollegeStudent extends Student{
	int year = 0;
	String  major = null;
	public void setYear(int y){
		this.year = y;
	}
	public void setMajor(String m){
		this.major = m;
	}
	public int getYear(){
		return this.year;
	}
	public String getMajor(){
		return this.major;
	}
}

class Aat4
{
	public static void main(String args[]){
		CollegeStudent c = new CollegeStudent();
		c.setName("Chaitanya");
		c.setRollNo(5);
		c.setYear(4);
		c.setMajor("Electrical and Electronics");
		System.out.println("The details of college student are \n\t Name : "+c.getName()+"\n\t Rollno : "+c.getRollNo()+"\n\t Year : "+c.getYear()+"\n\t Department : "+c.getMajor());
		
		Teacher t = new Teacher();
		t.setName("Chaitanya");
		t.setSalary(50000d);
		t.setSubject("English");
		System.out.println("The details of Teacher are \n\t Name : "+t.getName()+"\n\t Salary : "+t.getSalary()+"\n\t Subject : "+t.getSubject());
	}
}
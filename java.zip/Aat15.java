import java.util.*;
import java.lang.*;

class Aat15
{
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a String 1 : ");
		String str1 = sc.nextLine();
		System.out.println("Enter a String 2 : ");
		String str2 = sc.nextLine();
		int i = 0;
		if(str1.length() < str1.length()){
			for(i = 0; i<str1.length(); i++)
				System.out.print(str1.charAt(i)+""+str2.charAt(i));
			for(;i<str2.length(); i++)
				System.out.print(str2.charAt(i));
		}
		else{
			for(i = 0; i<str2.length(); i++)
				System.out.print(str1.charAt(i)+""+str2.charAt(i));
			for(;i<str1.length(); i++)
				System.out.print(str1.charAt(i));
		}
	}
}
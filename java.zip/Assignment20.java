import java.util.*;
import java.lang.*;
class Assignment20
{
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter Number: ");
		int a = sc.nextInt();
		int temp = a;
		sc.close();
		int sum = 0;
		while(a > 0){
			sum = (sum*10)+(a%10);
			a /= 10;
		}
		System.out.print("Reverse of the Number: "+sum);
	}
}
import java.util.*;
class Testing
{
	public static void main(String args[]){
		System.out.println("MAS - Testing Performance Batch");
	}
}
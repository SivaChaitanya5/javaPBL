import java.util.*;
import java.lang.*;
class Assignment6
{
	public static void main(String args[]){
		
		if(args.length == 0)
			System.out.println("No values");
		else{
			int a = args.length;
			for(int i = 0; i < a-1; i++)
				System.out.print(args[i]+" , ");
			System.out.print(args[a-1]);
		}
	}
}
import java.util.*;
import java.lang.*;

class Aat17
{
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a String : ");
		String str = sc.nextLine();
		System.out.println("Enter a Number : ");
		int ch = sc.nextInt();
		if(ch <= str.length() && ch >= 0){
			String sub = new StringBuffer(str).substring(str.length()-ch);
			for(int i =0; i<ch; i++)
			System.out.print(sub);
		}
		else
			System.out.println("Invalid number");
	}
}
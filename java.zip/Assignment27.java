import java.util.*;
import java.lang.*;
class Assignment27
{
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter size of Array : ");
		int size = sc.nextInt();
		int[] arr = new int[size];
		System.out.print("Enter elements of Array : ");
		for(int i = 0; i<size; i++){
			arr[i] = sc.nextInt();
		}
		
		for(int i = 0; i<size; i++){
			System.out.print((char)arr[i]+"\t");
		}
		
	}
}
import java.util.*;
import java.lang.*;

class Aat8
{
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a String 1 : ");
		String str1 = sc.nextLine();
		System.out.println("Enter a String 2 : ");
		String str2 = sc.nextLine();
		str1 = str1.toLowerCase();
		str2 = str2.toLowerCase();
		if(str1.charAt(str1.length()-1) == (str2.charAt(0)))
			System.out.println("Modified String : "+str1.concat(str2.substring(1)));
		else
			System.out.println("Modified String : "+str1.concat(str2));
	}
}
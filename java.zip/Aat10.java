import java.util.*;
import java.lang.*;

class Aat10
{
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a String : ");
		String str = sc.nextLine();
		if(str.length()%2 == 0)
			for(int i = 0; i < str.length()/2; i++)
				System.out.print(str.charAt(i));
		else
			System.out.println("null");
	}
}
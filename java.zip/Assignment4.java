import java.util.*;
import java.lang.*;
class Assignment4
{
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.println("Give a number: ");
		int a = sc.nextInt();
		if(a > 0)
			System.out.println("Given number "+a+" is Positive");
		else if(a < 0)
			System.out.println("Given number "+a+" is Negative");
		else
			System.out.println("Given number is Zero");
	}
}
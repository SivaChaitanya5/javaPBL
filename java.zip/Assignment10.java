import java.util.*;
import java.lang.*;
class Assignment10
{
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter Characters: ");
		char a = sc.next().charAt(0);
		sc.close();
		if((a >= 'a' && a <= 'z'))
			System.out.println(a+" -> "+(char)(a-32));
		else if((a >= 'A' && a <= 'Z'))
			System.out.println(a+" -> "+(char)(a+32));
		else
			System.out.println("Invalid Character");
	}
}
import java.util.ArrayList;
import java.util.List;

public class Video {
	private List<String> title = new ArrayList<String>();
	static List<String> copy = null;
	static int size;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
				
	}

	public List<String> getTitle() {
		return title;
	}

	public void setTitle(List<String> title) {
		this.title = title;
	}
	Video() {
		title.add("Java Tutorials");
		title.add("Python Tutorials");
		title.add("SAP Tutorials");
		copy = new ArrayList<String>(title);
		size = copy.size();
	}

}

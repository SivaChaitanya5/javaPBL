import java.util.InputMismatchException;
import java.util.Scanner;

public class VideoStore {
	
	Video v;
	int[][] rate ;
	public VideoStore() {
		// TODO Auto-generated constructor stub
		v = new Video();
		rate = new int[Video.size][2];
	}
	
	public void addVideo(String s) {
		v.getTitle().add(s);
	}

	public void checkOut(String s) {
		if (v.getTitle().contains(s)) {
			v.getTitle().remove(s);
			System.out.println("Book Name : " + s + "\n Checked out Successfully");
		} else
			System.out.println("The Video you want is not there");
	}

	public void returnVideo(String s) {
		if (Video.copy.contains(s)) {
			v.getTitle().add(s);
			System.out.println("Video Name : " + s + "\n Received Successfully");
			receiveRating(s);
		} else
			System.out.println("This Video does not belong to this shop");
	}

	public void receiveRating(String s) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Give your Rating in range of 1 - 5 : ");
		try {
			int temp = sc.nextInt();
			System.out.println(Video.size);
			rate[Video.copy.indexOf(s)][0] += temp;
			rate[Video.copy.indexOf(s)][1]++;
			System.out.println("The total Rating of this Video is "
					+ (float) (rate[Video.copy.indexOf(s)][0] / rate[Video.copy.indexOf(s)][1]));
		} catch (InputMismatchException e) {
			System.out.print("Invalid Input");
		}
	}

	public void listInventory() {
		System.out.println("List of Video Inventorey in the shop :");
		for (int i = 0; i < (v.getTitle()).size(); i++) {
			System.out.println((i + 1) + " . " + v.getTitle().get(i));
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		VideoStore vs = new VideoStore();
		Scanner sc = new Scanner(System.in);
		int ch = 'y';
		while (ch != 'n') {
			System.out.println("Choose your option : " + "\n 1. Buy a Video\n 2. Return a Video");
			System.out.print("Enter your choice : ");
			// System.out.println(vs.v.getTitle());
			try {
				switch (sc.nextInt()) {
				case 1:
					vs.listInventory();
					System.out.print("Please enter the video name you want to buy : ");
					Scanner sc1 = new Scanner(System.in);
					vs.checkOut(sc1.nextLine());
					break;
				case 2:
					System.out.print("Please enter the video name you want to return : ");
					Scanner sc2 = new Scanner(System.in);
					vs.returnVideo(sc2.nextLine());
					break;
				default:
					System.out.print("Invalid Choice");
					break;
				}
			} catch (InputMismatchException e) {
				System.out.print("Invalid Input");
			}
			try {
				Scanner sc1 = new Scanner(System.in);
				System.out.print("Do you wish to continue (y/n): ");
				ch = sc1.next().charAt(0);
			} catch (InputMismatchException e) {
				System.out.print("Invalid Input");
			}
		}
		sc.close();

	}

}

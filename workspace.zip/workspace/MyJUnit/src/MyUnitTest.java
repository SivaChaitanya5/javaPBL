import static org.junit.Assert.*;

import org.junit.Test;

public class MyUnitTest {

	@Test
	public void test() {
		MyUnit m = new MyUnit();
		String s = "liril";
		assertTrue(m.palindromeCheck(s));
	}

}

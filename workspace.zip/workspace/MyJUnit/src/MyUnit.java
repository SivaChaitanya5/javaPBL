
public class MyUnit {
	public boolean palindromeCheck(String s){
		StringBuffer str = new StringBuffer(s);
		if(str.reverse().toString().equals(s))
			return true;
		else
			return false;
	}
}

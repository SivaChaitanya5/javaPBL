import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses(
		{
			EmployeeTest.class,
			MyUnitTest.class
		})

public class JunitTestSuite {

}

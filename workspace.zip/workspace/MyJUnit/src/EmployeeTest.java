import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class EmployeeTest {

	@Test
	public void test() {
		Employee e = new Employee();
		List<String> arrList = new ArrayList<String>();
		arrList.add("Chaitanya");
		arrList.add("Rahul");
		assertTrue((e.findName((ArrayList<String>) arrList,"Chaitanya")).equals("FOUND"));
	}

}